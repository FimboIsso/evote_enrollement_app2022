package issonet.com.vote_enronlement_2019_new;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class aboutUsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us);
    }
}
